package mahfuz.virtualcr01;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class signUp extends AppCompatActivity {


    EditText name,roll,phone,email,pass;
    Button signUp;
    RadioButton student,cr;
    FirebaseAuth auth;
    Firebase PrimaryKeyUid;
    FirebaseFirestore myFirestore;
    public String myname,myroll,myphone,myemail,mypass,uid,catagory;
    ProgressBar progressBar;
    String identity;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);




        auth =FirebaseAuth.getInstance();
        myFirestore = FirebaseFirestore.getInstance();

        Firebase.setAndroidContext(signUp.this);





        name = (EditText) findViewById(R.id.name);
        roll = (EditText) findViewById(R.id.roll);
        phone = (EditText) findViewById(R.id.phone);
        email = (EditText) findViewById(R.id.email);
        pass = (EditText) findViewById(R.id.pass);
        signUp = (Button) findViewById(R.id.signUp);
        progressBar = (ProgressBar) findViewById(R.id.progressBar) ;

        student= (RadioButton) findViewById(R.id.student);
        cr= (RadioButton) findViewById(R.id.cr);







        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               progressBar.setVisibility(View.VISIBLE);
                myname = name.getText().toString().trim();
                myroll = roll.getText().toString().trim();
                myphone = phone.getText().toString().trim();
                myemail = email.getText().toString().trim();
                mypass = pass.getText().toString().trim();

                if(student.isChecked()) {
                    identity="student";
                }
                else if(cr.isChecked()) {
                    identity="cr";
                }



                if(!TextUtils.isEmpty(myname) && !TextUtils.isEmpty(myroll) && !TextUtils.isEmpty(myemail) &&!TextUtils.isEmpty(mypass) ) {


                    auth.createUserWithEmailAndPassword(myemail, mypass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                progressBar.setVisibility(View.INVISIBLE);
                                Intent homeintent = new Intent(mahfuz.virtualcr01.signUp.this, MainActivity.class);
                                Toast.makeText(mahfuz.virtualcr01.signUp.this, "Registration successfully completed", Toast.LENGTH_SHORT).show();
                                startActivity(homeintent);
                                finish();


// Write data to the database


                                uid = auth.getUid();

                            //writing into firebase database

                                PrimaryKeyUid = new Firebase("https://virtual-cr.firebaseio.com/users/" + uid);
                                Firebase userName = PrimaryKeyUid.child("name");
                                userName.setValue(myname);
                                Firebase userRoll = PrimaryKeyUid.child("roll");
                                userRoll.setValue(myroll);
                                Firebase userPhone = PrimaryKeyUid.child("phone");
                                userPhone.setValue(myphone);
                                Firebase userEmail = PrimaryKeyUid.child("email");
                                userEmail.setValue(myemail);
                                Firebase userPass = PrimaryKeyUid.child("password");
                                userPass.setValue(mypass);


                            //Writing into firestore

                                Map<String, String> setvalue = new HashMap<>();
                                setvalue.put("name", myname);
                                setvalue.put("roll", myroll);
                                setvalue.put("phone", myphone);
                                setvalue.put("email", myemail);
                                setvalue.put("pass", mypass);
                                setvalue.put("identity", identity);
                                myFirestore.collection("user").document(uid).set(setvalue);


                            }
                            /**
                            else {


                                Toast.makeText(mahfuz.virtualcr01.signUp.this, "Registration Failed! Please insert a valid email and a strong password and try again", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.INVISIBLE);
                            }

                             */
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            if(e instanceof FirebaseAuthUserCollisionException)
                            {
                                Toast.makeText(mahfuz.virtualcr01.signUp.this,"An account already exist with this email",Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.INVISIBLE);
                            }
                            else if(e instanceof FirebaseAuthWeakPasswordException)
                            {
                                Toast.makeText(mahfuz.virtualcr01.signUp.this,"Please use a strong password using both number & characters minimum 6 digit",Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.INVISIBLE);
                            }
                            else if(e instanceof FirebaseAuthInvalidCredentialsException)
                            {
                                Toast.makeText(mahfuz.virtualcr01.signUp.this,"Invalid Email format",Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.INVISIBLE);
                            }
                        }
                    });





                }

                else{
                    Toast.makeText(mahfuz.virtualcr01.signUp.this,"Please fill up all the required fields",Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.INVISIBLE);
                }








            }
        });

    }


}
